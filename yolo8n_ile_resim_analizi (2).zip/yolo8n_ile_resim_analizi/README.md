# 📸 Discord YOLO Nesne Tespit Botu

Discord'a gönderilen fotoğraflardaki nesneleri YOLOv8 kullanarak tespit eden bir bot.

## 🚀 Özellikler

- Otomatik fotoğraf tespiti
- YOLOv8 ile gerçek zamanlı nesne tespiti
- 80+ farklı nesne türünü tanıma
- Tespit edilen nesneleri işaretli resim olarak gönderme
- Türkçe nesne isimleri
- PNG, JPG, JPEG, GIF, WEBP format desteği
- Offline çalışma (internet sadece Discord için gerekli)

## 📋 Gereksinimler

- Python 3.8 veya üzeri
- Discord Bot Token
- 2-3 GB boş disk alanı (YOLO modeli için)

## 🔧 Kurulum

### 1. Gerekli paketleri yükleyin:

```bash
pip install -r requirements.txt
```

### 2. Discord Bot Ayarları

Bot token'iniz zaten `.env` dosyasında kayıtlı. Eğer bot'u Discord Developer Portal'dan oluşturmadıysanız:

1. https://discord.com/developers/applications adresine gidin
2. "New Application" butonuna tıklayın
3. Sol menüden "Bot" sekmesine gidin
4. "Reset Token" ile yeni token alabilirsiniz (isteğe bağlı)
5. **Önemli:** Aşağıdaki ayarları yapın:
   - "MESSAGE CONTENT INTENT" ✅ Aktif
   - "SERVER MEMBERS INTENT" ✅ Aktif

### 3. Bot'u Sunucunuza Ekleyin

1. Developer Portal'da "OAuth2" > "URL Generator" bölümüne gidin
2. **SCOPES:** `bot` seçin
3. **BOT PERMISSIONS:** 
   - Read Messages/View Channels
   - Send Messages
   - Read Message History
   - Attach Files
4. Oluşan URL'yi tarayıcınıza yapıştırın ve bot'u sunucunuza ekleyin

## ▶️ Çalıştırma

```bash
python bot.py
```

**İlk çalıştırmada:**
- YOLOv8 modeli otomatik olarak indirilecek (~6 MB)
- PyTorch modelleri yüklenecek
- Bu işlem 1-2 dakika sürebilir

Bot başarıyla başladığında şu mesajları göreceksiniz:
```
YOLO modeli yükleniyor...
YOLO modeli yüklendi!
Bot_İsmi olarak giriş yapıldı!
Bot ID: 1342463875127185418
Bot hazır ve fotoğraf bekliyor...
🚀 Bot başlatılıyor...
```

## 💡 Kullanım

### Otomatik Analiz
Herhangi bir kanala fotoğraf gönderin, bot otomatik olarak analiz edecek:

```
[Kullanıcı fotoğraf gönderir]
Bot: � YOLO Nesne Tespiti:

Toplam 3 farklı nesne türü tespit edildi:

• köpek (dog): 1 adet (güven: %94.5)
• kişi/insan (person): 2 adet (güven: %88.3)
• araba (car): 1 adet (güven: %76.2)

[+ İşaretlenmiş resim eklenir]
```

### Komutlar

- `!test` - Bot'un çalışıp çalışmadığını kontrol edin
- `!yardim` - Yardım mesajını görüntüleyin

## 📁 Proje Yapısı

```
.
├── bot.py              # Ana bot kodu
├── requirements.txt    # Python bağımlılıkları
├── .env               # Çevre değişkenleri (TOKEN)
├── .gitignore         # Git ignore dosyası
├── yolov8n.pt         # YOLO modeli (ilk çalıştırmada indirilir)
└── README.md          # Bu dosya
```

## ⚠️ Önemli Notlar

- `.env` dosyasını asla paylaşmayın veya GitHub'a yüklemeyin!
- YOLO tamamen offline çalışır, API key gerekmez
- İlk çalıştırma diğerlerinden daha uzun sürer (model indirme)
- Bot'un çalışması için 7/24 açık bir sunucuda çalıştırılması gerekir
- GPU varsa otomatik kullanılır, yoksa CPU ile çalışır (biraz daha yavaş)

## 🔒 Güvenlik

- Token'larınızı kimseyle paylaşmayın
- `.gitignore` dosyası `.env` dosyasını otomatik olarak Git'ten hariç tutar
- Token'ınız sızdıysa Discord Developer Portal'dan hemen yenileyin

## 🐛 Sorun Giderme

**Bot çevrimiçi görünmüyor:**
- Token'ın doğru olduğundan emin olun
- Intents ayarlarını kontrol edin (MESSAGE CONTENT INTENT aktif olmalı)

**Bot fotoğrafları analiz etmiyor:**
- YOLO modelinin düzgün yüklendiğinden emin olun
- İnternet bağlantınızı kontrol edin (Discord için)
- Terminal'de hata mesajlarını kontrol edin

**"No module named 'ultralytics'" hatası:**
- `pip install -r requirements.txt` komutunu tekrar çalıştırın

**Yavaş çalışıyor:**
- İlk çalıştırma her zaman daha yavaştır
- CPU kullanıyorsanız normal, GPU varsa daha hızlı olur
- Model yüklendikten sonra analiz hızlanır

## 📝 Lisans

Bu proje açık kaynaklıdır ve özgürce kullanılabilir.
