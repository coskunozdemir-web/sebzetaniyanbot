import discord
from discord.ext import commands
import os
from dotenv import load_dotenv
import requests
from io import BytesIO
from PIL import Image
from ultralytics import YOLO
import cv2
import numpy as np

# .env dosyasından çevre değişkenlerini yükle
load_dotenv()

# Discord bot token
DISCORD_TOKEN = os.getenv('DISCORD_TOKEN')

# YOLO modeli yükleniyor
print("YOLO modeli yükleniyor...")
model = YOLO('best.pt')
print("YOLO modeli yüklendi!")

# Yemek öneri sistemi (basit versiyon)
recipe_map = {
    "apple": ["Elmalı tart", "Elmalı crumble", "Elmalı salata"],
    "banana": ["Muzlu smoothie", "Muzlu pankek", "Muzlu milkshake"],
    "orange": ["Portakal suyu", "Portakallı kek"],
    "carrot": ["Havuç salatası", "Havuçlu kek", "Sebze çorbası"],
    "broccoli": ["Brokoli salatası", "Brokoli haşlama", "Sebzeli makarna"],
    "tomato": ["Domates çorbası", "Menemen", "Domates soslu makarna"],
    "potato": ["Patates kızartması", "Patates püresi", "Fırında patates"],
    "egg": ["Omlet", "Menemen", "Haşlanmış yumurta"],
    "chicken": ["Tavuk sote", "Fırında tavuk", "Tavuklu makarna"],
    "cow": ["Et sote", "Kavurma", "Izgara et"],
    "sheep": ["Kuzu tandır", "Kuzu pirzola"],
    "fish": ["Izgara balık", "Balık buğulama"],
}

# Bot intents ayarları
intents = discord.Intents.default()
intents.message_content = True
intents.messages = True

# Bot oluştur
bot = commands.Bot(command_prefix='!', intents=intents)


@bot.event
async def on_ready():
    print(f'{bot.user} olarak giriş yapıldı!')
    print(f'Bot ID: {bot.user.id}')
    print('Bot hazır!')


@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    if message.attachments:
        for attachment in message.attachments:
            if any(attachment.filename.lower().endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.gif', '.webp']):
                try:
                    async with message.channel.typing():
                        response_text, annotated_image = analyze_image_with_yolo(attachment.url)

                        if annotated_image:
                            await message.reply(response_text, file=discord.File(annotated_image, filename='detected.jpg'))
                        else:
                            await message.reply(response_text)

                except Exception as e:
                    await message.reply(f"❌ Hata oluştu: {str(e)}")

    await bot.process_commands(message)


def analyze_image_with_yolo(image_url):
    """YOLO kullanarak resim analizi + yemek önerileri"""
    try:
        response = requests.get(image_url)
        image = Image.open(BytesIO(response.content))
        img_array = np.array(image)

        # YOLO inference
        results = model(img_array)
        detections = results[0]

        detected_objects = {}

        for box in detections.boxes:
            class_id = int(box.cls[0])
            class_name = model.names[class_id]
            confidence = float(box.conf[0])

            if confidence > 0.5:
                if class_name in detected_objects:
                    detected_objects[class_name]["count"] += 1
                    detected_objects[class_name]["conf"].append(confidence)
                else:
                    detected_objects[class_name] = {"count": 1, "conf": [confidence]}

        # Türkçe isim çevirileri
        turkish_names = {
            'apple': 'elma',
            'banana': 'muz',
            'orange': 'portakal',
            'carrot': 'havuç',
            'broccoli': 'brokoli',
            'tomato': 'domates',
            'potato': 'patates',
            'egg': 'yumurta',
            'chicken': 'tavuk',
            'cow': 'inek (et)',
            'sheep': 'kuzu',
            'fish': 'balık',
        }

        # Sonuç metni
        if detected_objects:
            result_text = "🔍 **YOLO Nesne Tespiti Sonuçları:**\n\n"

            for name, data in detected_objects.items():
                tr = turkish_names.get(name, name)
                avg_conf = sum(data["conf"]) / len(data["conf"]) * 100
                result_text += f"• **{tr}** ({name}) → {data['count']} adet (güven: %{avg_conf:.1f})\n"

            # --- YEMEK ÖNERİLERİ ---
            recipes = []
            for obj in detected_objects:
                if obj in recipe_map:
                    recipes.extend(recipe_map[obj])

            if recipes:
                result_text += "\n🍽️ **Bu malzemelerle yapılabilecek yemekler:**\n"
                for yemek in list(dict.fromkeys(recipes))[:6]:
                    result_text += f"• {yemek}\n"
            else:
                result_text += "\n🍽️ Bu malzemelere uygun tarif bulunamadı."

            # Annotated image
            annotated_img = results[0].plot()
            annotated_img_rgb = cv2.cvtColor(annotated_img, cv2.COLOR_BGR2RGB)
            annotated_pil = Image.fromarray(annotated_img_rgb)

            buffer = BytesIO()
            annotated_pil.save(buffer, format="JPEG")
            buffer.seek(0)

            return result_text, buffer

        return "❌ Resimde tanınabilir nesne bulunamadı.", None

    except Exception as e:
        return f"❌ Analiz hatası: {str(e)}", None


@bot.command(name='test')
async def test(ctx):
    await ctx.send("✅ Bot çalışıyor! Bir fotoğraf gönder.")


@bot.command(name='yardim')
async def yardim(ctx):
    await ctx.send("📸 Fotoğraf gönder → YOLO ile nesne analizi + yemek önerisi alırsın.")


# Bot çalıştır
if __name__ == '__main__':
    if not DISCORD_TOKEN:
        print("❌ DISCORD_TOKEN bulunamadı!")
    else:
        print("🚀 Bot başlatılıyor...")
        bot.run(DISCORD_TOKEN)
